var dir_617ecf4707934de2318090466f038e83 =
[
    [ "Composite", "dir_3cde2ca7af9740c5b0d23b8cc04dfa69.html", "dir_3cde2ca7af9740c5b0d23b8cc04dfa69" ],
    [ "CatmullClarkT.hh", "a00563.html", [
      [ "CatmullClarkT", "a00072.html", "a00072" ]
    ] ],
    [ "CompositeLoopT.hh", "a00564.html", [
      [ "CompositeLoopT", "a00082.html", "a00082" ],
      [ "EVCoeff", "a00113.html", "a00113" ],
      [ "compute_weight", "a00088.html", "a00088" ]
    ] ],
    [ "CompositeSqrt3T.hh", "a00565.html", [
      [ "CompositeSqrt3T", "a00083.html", "a00083" ],
      [ "FVCoeff", "a00128.html", "a00128" ],
      [ "compute_weight", "a00089.html", "a00089" ]
    ] ],
    [ "LongestEdgeT.hh", "a00566.html", [
      [ "CompareLengthFunction", "a00081.html", "a00081" ],
      [ "LongestEdgeT", "a00168.html", "a00168" ]
    ] ],
    [ "LoopT.hh", "a00567.html", "a00567" ],
    [ "ModifiedButterFlyT.hh", "a00568.html", [
      [ "ModifiedButterflyT", "a00191.html", "a00191" ]
    ] ],
    [ "Sqrt3InterpolatingSubdividerLabsikGreinerT.hh", "a00569.html", "a00569" ],
    [ "Sqrt3T.hh", "a00570.html", "a00570" ],
    [ "SubdividerT.hh", "a00571.html", "a00571" ]
];