Please look into the doxygen configuration (Generated from Doc/history.docu) 

The latest changelog for the master can be found here:
http://openmesh.org/Daily-Builds/Doc/a00002.html
